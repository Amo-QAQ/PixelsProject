local s = app.activeSprite
if not s then print("no sprite") return end
print(string.format("canvas %dx%d  frames %d  layers %d  slices %d", s.width, s.height, #s.frames, #s.layers, #s.slices))
for i,l in ipairs(s.layers) do
  local cels, emptyCels = 0, 0
  local x0,y0,x1,y1 = 99999,99999,-1,-1
  for f=1,#s.frames do
    local cel = l:cel(f)
    if cel then
      cels = cels + 1
      local b = cel.bounds
      local img = cel.image
      local pos = cel.position
      local any = false
      for py=0,img.height-1 do
        for px=0,img.width-1 do
          if app.pixelColor.rgbaA(img:getPixel(px,py)) > 0 then
            any = true
            local gx, gy = pos.x+px, pos.y+py
            if gx<x0 then x0=gx end
            if gy<y0 then y0=gy end
            if gx>x1 then x1=gx end
            if gy>y1 then y1=gy end
          end
        end
      end
      if not any then emptyCels = emptyCels + 1 end
    end
  end
  print(string.format("L%d %-12s visible=%-5s cels=%d emptyCels=%d bbox=%s",
    i-1, l.name, tostring(l.isVisible), cels, emptyCels,
    (x1>=x0) and string.format("(%d,%d)-(%d,%d) %dx%d", x0,y0,x1,y1, x1-x0+1, y1-y0+1) or "EMPTY"))
end
for i,sl in ipairs(s.slices) do
  local b = sl.bounds
  print(string.format("S%d %-12s bounds=(%d,%d) %dx%d", i-1, sl.name, b.x,b.y,b.width,b.height))
end
for i,t in ipairs(s.tags) do
  print(string.format("T%d %s frames %d-%d", i-1, t.name, t.fromFrame.frameNumber, t.toFrame.frameNumber))
end