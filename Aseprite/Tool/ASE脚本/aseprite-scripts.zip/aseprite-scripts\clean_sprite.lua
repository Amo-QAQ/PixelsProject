-- clean_sprite.lua  (Aseprite 1.3+)
--
-- Default: clip every cel image to the canvas rectangle (drops hidden pixels
-- that sit outside the canvas). Deleting empty layers is OPTIONAL and OFF.
--
-- Usage:  File > Scripts > clean_sprite
--         aseprite -b file.aseprite --script clean_sprite.lua --save-as out.aseprite

local OPT = {
  DELETE_EMPTY_LAYERS = false,   -- true = remove layers that have no cel
  CLIP_CELS_TO_CANVAS = true,    -- true = clip cel images to canvas (recommended)
}

local s = app.activeSprite
if not s then print("no active sprite") return end
local W, H = s.width, s.height

local emptyLayers = {}
for i, l in ipairs(s.layers) do
  local has = false
  if l.isImage then
    for f = 1, #s.frames do
      if l:cel(f) then has = true break end
    end
  end
  if not has then table.insert(emptyLayers, l) end
end

print(string.format("canvas %dx%d  layers %d  empty layers %d", W, H, #s.layers, #emptyLayers))
for _, l in ipairs(emptyLayers) do
  print(string.format("  empty layer: %s -> %s", l.name,
    OPT.DELETE_EMPTY_LAYERS and "WILL BE DELETED" or "kept (option off)"))
end

local removedLayers, clippedCels, freedPixels = 0, 0, 0

app.transaction(function()
  if OPT.DELETE_EMPTY_LAYERS then
    for _, l in ipairs(emptyLayers) do
      if #s.layers > 1 then
        s:deleteLayer(l)
        removedLayers = removedLayers + 1
      end
    end
  end

  if OPT.CLIP_CELS_TO_CANVAS then
    for _, l in ipairs(s.layers) do
      if l.isImage then
        for f = 1, #s.frames do
          local cel = l:cel(f)
          if cel then
            local img = cel.image
            local pos = cel.position
            local outside = (pos.x < 0) or (pos.y < 0) or (pos.x + img.width > W) or (pos.y + img.height > H)
            if outside then
              local x0 = math.max(0, pos.x)
              local y0 = math.max(0, pos.y)
              local x1 = math.min(W, pos.x + img.width)
              local y1 = math.min(H, pos.y + img.height)
              if x1 <= x0 or y1 <= y0 then
                cel.image = Image(1, 1, img.colorMode)
                cel.position = Point(0, 0)
              else
                local ni = Image(x1 - x0, y1 - y0, img.colorMode)
                for yy = 0, (y1 - y0) - 1 do
                  for xx = 0, (x1 - x0) - 1 do
                    ni:putPixel(xx, yy, img:getPixel(x0 - pos.x + xx, y0 - pos.y + yy))
                  end
                end
                freedPixels = freedPixels + (img.width * img.height - ni.width * ni.height)
                cel.image = ni
                cel.position = Point(x0, y0)
              end
              clippedCels = clippedCels + 1
            end
          end
        end
      end
    end
  end
end)

app.refresh()
print(string.format("done: layers removed=%d  cels clipped=%d  pixels freed~%d",
  removedLayers, clippedCels, freedPixels))