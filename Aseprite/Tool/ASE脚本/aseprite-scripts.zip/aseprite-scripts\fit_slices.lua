-- fit_slices.lua  (Aseprite 1.3+)
-- Shrink every slice bounds to the non-transparent pixels of the visible layers.
-- Usage: File > Scripts > fit_slices   (or: aseprite -b file.aseprite --script fit_slices.lua)

local sprite = app.activeSprite
if not sprite then print("no active sprite"); return end
if not sprite.slices or #sprite.slices == 0 then print("no slices"); return end

local found = 0
app.transaction(function()
  for i, sl in ipairs(sprite.slices) do
    local b = sl.bounds
    local x0, y0 = b.x + b.width, b.y + b.height
    local x1, y1 = -1, -1
    for _, layer in ipairs(sprite.layers) do
      if layer.isImage and layer.isVisible then
        for f = 1, #sprite.frames do
          local ok, cel = pcall(function() return layer:cel(f) end)
          if ok and cel then
            local img = cel.image
            local pos = cel.position
            local ry0 = math.max(b.y, pos.y)
            local ry1 = math.min(b.y + b.height - 1, pos.y + img.height - 1)
            local rx0 = math.max(b.x, pos.x)
            local rx1 = math.min(b.x + b.width - 1, pos.x + img.width - 1)
            for oy = ry0, ry1 do
              for ox = rx0, rx1 do
                local a = app.pixelColor.rgbaA(img:getPixel(ox - pos.x, oy - pos.y))
                if a > 0 then
                  if ox < x0 then x0 = ox end
                  if oy < y0 then y0 = oy end
                  if ox > x1 then x1 = ox end
                  if oy > y1 then y1 = oy end
                end
              end
            end
          end
        end
      end
    end
    if x1 >= x0 and y1 >= y0 then
      sl.bounds = Rectangle(x0, y0, x1 - x0 + 1, y1 - y0 + 1)
      found = found + 1
    end
  end
end)

app.refresh()
print(string.format("fitted %d of %d slice(s)", found, #sprite.slices))
