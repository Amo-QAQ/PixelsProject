Aseprite 脚本包（3 个）
========================

适用版本：Aseprite 1.3.18 及以上（在 1.3.18.6 上测试通过）
文件格式：Lua 脚本，纯 ASCII，无 BOM，任何编码环境都能读


安装（Windows）
---------------
1. 打开这个文件夹（不存在就自己建，注意 AppData 是隐藏文件夹）：

     %APPDATA%\Aseprite\scripts

   实际路径一般是：
     C:\Users\你的用户名\AppData\Roaming\Aseprite\scripts

2. 把本文件夹里的 .lua 文件全部拷进去。
3. 重启 Aseprite。
4. 菜单：文件 > 脚本（File > Scripts），就能看到这三个脚本。
   如果没出现，点「文件 > 脚本 > 重新扫描脚本文件夹」。


三个脚本分别干什么
------------------

1) clean_sprite.lua  ——  清理文件（主力）
   作用：把每个 cel 的像素裁到「画布范围」内，丢掉画布外那些看不见、
        却一直跟着文件的像素；可选删除没有任何 cel 的空图层。
   默认：只裁 cel，不删图层。

   配置在文件开头：
     local OPT = {
       DELETE_EMPTY_LAYERS = false,   -- true = 删除没有任何 cel 的图层
       CLIP_CELS_TO_CANVAS = true,    -- true = 把 cel 裁到画布（推荐）
     }

   运行后会在脚本控制台打印类似：
     canvas 16x16  layers 4  empty layers 1
       empty layer: new -> kept (option off)
     done: layers removed=0  cels clipped=54  pixels freed~129498

   实测参考：一个 16x16、27 帧的文件，cel 实际背着 60x63 的像素，
            跑完 10997 字节 -> 7603 字节，27 帧导出结果逐帧一致。

2) fit_slices.lua  ——  把切片收到内容边界
   作用：遍历精灵的每个切片，扫描所有可见图层的不透明像素，
        把切片边界收到刚好包住内容。
   用法：选中精灵 > 文件 > 脚本 > fit_slices
   注意：按「所有可见图层」的并集来收；只想算某一层就先隐藏其他层。

3) inspect_sprite.lua  ——  只读检查，不改文件
   作用：打印画布尺寸、帧数、每个图层的可见性 / cel 数 / 内容包围盒、
        每个切片的边界、所有标签。
   用途：怀疑文件"不干净"时先用它看一眼，再决定要不要跑 clean_sprite。


安全提示
--------
- clean_sprite 会丢掉画布外的像素，这是不可逆的。跑之前先「文件 > 另存为」
  备份一份。
- 三个脚本都是整段包在一个事务里的，跑错了按一次 Ctrl+Z 就能整体回退。
- 只处理当前打开的精灵，不会碰别的文件。


命令行用法（可选，批量处理时有用）
----------------------------------
  aseprite -b sprite.aseprite --script clean_sprite.lua --save-as out.aseprite
  aseprite -b sprite.aseprite --script inspect_sprite.lua

提示：如果 Aseprite 本体正开着，命令行可能会把文件转交给已开的窗口而
不执行保存；批量跑之前先把 Aseprite 关掉。
